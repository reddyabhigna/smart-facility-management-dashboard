const RAIL_CLASSES = {
  teal: "rail-teal",
  amber: "rail-amber",
  red: "rail-red",
  indigo: "rail-indigo",
  dim: "rail-dim",
};

export default function Panel({ title, subtitle, rail = "dim", action, className = "", children }) {
  return (
    <div className={`panel ${className}`}>
      <div className={`panel-rail ${RAIL_CLASSES[rail]}`} />
      {(title || action) && (
        <div className="flex items-start justify-between px-5 pt-4 pb-2">
          <div>
            {title && <h3 className="font-display text-[13px] font-semibold text-ink tracking-wide">{title}</h3>}
            {subtitle && <p className="text-xs text-ink-dim mt-0.5">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      <div className="px-5 pb-5 pt-1">{children}</div>
    </div>
  );
}
