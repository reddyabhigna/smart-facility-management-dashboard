export const CHART_COLORS = {
  teal: "#2FD3B0",
  amber: "#F5A93F",
  red: "#F2545B",
  indigo: "#7C93F7",
  grid: "#1E2740",
  axis: "#5B6784",
};

export const axisTickStyle = {
  fill: CHART_COLORS.axis,
  fontSize: 11,
  fontFamily: "'IBM Plex Mono', monospace",
};

export function ChartTooltip({ active, payload, label, formatter }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="bg-panel-raised border border-hairline rounded-md px-3 py-2 shadow-panel text-xs">
      {label && <div className="text-ink-dim mb-1.5 font-mono">{label}</div>}
      <div className="space-y-1">
        {payload.map((entry, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ background: entry.color || entry.fill }} />
            <span className="text-ink-muted">{entry.name}:</span>
            <span className="text-ink font-mono">
              {formatter ? formatter(entry.value, entry.name) : entry.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
