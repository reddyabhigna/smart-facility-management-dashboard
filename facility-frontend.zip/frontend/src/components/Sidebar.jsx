import { NavLink } from "react-router-dom";
import { Gauge, Building2, Zap, Wrench, Users, ShieldAlert, IndianRupee, Radio } from "lucide-react";

const NAV_ITEMS = [
  { to: "/", label: "Overview", icon: Gauge, end: true },
  { to: "/facilities", label: "Facilities", icon: Building2 },
  { to: "/energy", label: "Energy & Water", icon: Zap },
  { to: "/assets", label: "Assets & Maintenance", icon: Wrench },
  { to: "/occupancy", label: "Occupancy", icon: Users },
  { to: "/security", label: "Security & Alerts", icon: ShieldAlert },
  { to: "/costs", label: "Cost Reports", icon: IndianRupee },
];

export default function Sidebar() {
  return (
    <aside className="w-60 shrink-0 bg-panel border-r border-hairline flex flex-col h-screen sticky top-0">
      <div className="px-5 pt-6 pb-5 border-b border-hairline">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-signal-teal/10 flex items-center justify-center">
            <Radio size={15} className="text-signal-teal" strokeWidth={2} />
          </div>
          <div>
            <div className="font-display text-sm font-semibold text-ink leading-none">FacilityOS</div>
          </div>
        </div>
        <div className="text-[10px] text-ink-dim mt-2 tracking-wide">SMART FACILITY MANAGEMENT CONSOLE</div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}>
            <Icon size={16} strokeWidth={1.75} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="px-5 py-4 border-t border-hairline">
        <div className="text-[10px] text-ink-dim leading-relaxed">
          Data refreshes on each page load.
          <br />
          20 facilities \u00b7 5 cities
        </div>
      </div>
    </aside>
  );
}
