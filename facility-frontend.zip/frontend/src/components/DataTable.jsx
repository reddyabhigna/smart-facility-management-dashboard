export default function DataTable({ columns, rows, emptyLabel = "No records match these filters." }) {
  if (!rows || rows.length === 0) {
    return <div className="text-sm text-ink-dim py-10 text-center">{emptyLabel}</div>;
  }

  return (
    <div className="overflow-x-auto -mx-5">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="border-b border-hairline">
            {columns.map((col) => (
              <th
                key={col.key}
                className="text-left text-[11px] uppercase tracking-[0.08em] text-ink-dim font-medium px-5 py-2.5 whitespace-nowrap"
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={row.id ?? i} className="border-b border-hairline/60 hover:bg-panel-raised/50 transition-colors">
              {columns.map((col) => (
                <td key={col.key} className="px-5 py-2.5 text-ink-muted whitespace-nowrap">
                  {col.render ? col.render(row) : row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
