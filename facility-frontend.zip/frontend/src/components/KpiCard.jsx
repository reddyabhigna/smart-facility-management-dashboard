const RAIL_CLASSES = {
  teal: "rail-teal",
  amber: "rail-amber",
  red: "rail-red",
  indigo: "rail-indigo",
  dim: "rail-dim",
};

const ICON_COLOR = {
  teal: "text-signal-teal",
  amber: "text-signal-amber",
  red: "text-signal-red",
  indigo: "text-signal-indigo",
  dim: "text-ink-dim",
};

export default function KpiCard({ label, value, unit, sublabel, icon: Icon, rail = "dim", loading }) {
  return (
    <div className="panel">
      <div className={`panel-rail ${RAIL_CLASSES[rail]}`} />
      <div className="px-5 pt-4 pb-4 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="eyebrow">{label}</div>
          {loading ? (
            <div className="h-7 w-20 mt-2 bg-panel-raised rounded animate-pulse" />
          ) : (
            <div className="mt-1.5 flex items-baseline gap-1.5">
              <span className="readout text-2xl font-semibold">{value}</span>
              {unit && <span className="text-xs text-ink-dim">{unit}</span>}
            </div>
          )}
          {sublabel && <div className="text-xs text-ink-muted mt-1">{sublabel}</div>}
        </div>
        {Icon && (
          <div className={`shrink-0 ${ICON_COLOR[rail]}`}>
            <Icon size={18} strokeWidth={1.75} />
          </div>
        )}
      </div>
    </div>
  );
}
