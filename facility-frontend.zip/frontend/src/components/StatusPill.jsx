// Maps every status/severity/priority string in the dataset to a signal color.
const TONE_MAP = {
  // security / alert status
  Open: "red",
  Active: "amber",
  Closed: "teal",
  Resolved: "teal",
  // severity / priority
  High: "red",
  Medium: "amber",
  Low: "teal",
  // asset / maintenance status
  Inactive: "dim",
  Maintenance: "amber",
  Pending: "amber",
  "In Progress": "indigo",
  Completed: "teal",
};

const TONE_CLASSES = {
  teal: "bg-signal-teal/10 text-signal-teal",
  amber: "bg-signal-amber/10 text-signal-amber",
  red: "bg-signal-red/10 text-signal-red",
  indigo: "bg-signal-indigo/10 text-signal-indigo",
  dim: "bg-ink-dim/10 text-ink-dim",
};

export default function StatusPill({ value }) {
  const tone = TONE_MAP[value] || "dim";
  return (
    <span className={`pill ${TONE_CLASSES[tone]}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {value}
    </span>
  );
}
