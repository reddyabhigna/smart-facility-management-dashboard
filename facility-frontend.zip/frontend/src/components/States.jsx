import { AlertTriangle, Loader2 } from "lucide-react";

export function LoadingBlock({ label = "Loading data\u2026" }) {
  return (
    <div className="flex items-center gap-2 text-ink-dim text-sm py-10 justify-center">
      <Loader2 size={16} className="animate-spin" />
      {label}
    </div>
  );
}

export function ErrorBlock({ message = "Could not reach the API." }) {
  return (
    <div className="flex flex-col items-center gap-2 text-signal-red text-sm py-10 justify-center text-center">
      <AlertTriangle size={18} />
      <div>{message}</div>
      <div className="text-ink-dim text-xs max-w-xs">
        Check that the FastAPI backend is running at the configured API base URL.
      </div>
    </div>
  );
}
