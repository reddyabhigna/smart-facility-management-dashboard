import { useFetch } from "../hooks/useFetch";
import { endpoints } from "../api/client";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";

function StatusChip({ tone, label, value }) {
  const dot = { teal: "bg-signal-teal", amber: "bg-signal-amber", red: "bg-signal-red" }[tone];
  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-panel-raised border border-hairline">
      <span className={`w-1.5 h-1.5 rounded-full ${dot} ${tone === "red" ? "animate-pulse" : ""}`} />
      <span className="readout text-sm font-medium">{value}</span>
      <span className="text-[11px] text-ink-dim tracking-wide">{label}</span>
    </div>
  );
}

export default function Topbar({ title, subtitle }) {
  const { data: summary } = useFetch(endpoints.dashboardSummary, []);
  const { facilityId, setFacilityId } = useFacilityFilter();
  const { data: facilities } = useFetch(endpoints.facilities, []);

  return (
    <header className="sticky top-0 z-10 bg-canvas/95 backdrop-blur border-b border-hairline">
      <div className="px-8 pt-6 pb-4 flex items-start justify-between gap-6 flex-wrap">
        <div>
          <h1 className="font-display text-xl font-semibold text-ink">{title}</h1>
          {subtitle && <p className="text-sm text-ink-muted mt-1">{subtitle}</p>}
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <select
            value={facilityId}
            onChange={(e) => setFacilityId(e.target.value)}
            className="bg-panel border border-hairline rounded-md text-sm text-ink-muted px-3 py-1.5 focus:outline-none focus:border-signal-teal/50"
          >
            <option value="">All facilities</option>
            {facilities?.map((f) => (
              <option key={f.facility_id} value={f.facility_id}>
                {f.facility_name}
              </option>
            ))}
          </select>

          {summary && (
            <div className="flex items-center gap-2">
              <StatusChip tone="red" value={summary.open_security_events} label="OPEN EVENTS" />
              <StatusChip tone="amber" value={summary.active_alerts} label="ACTIVE ALERTS" />
              <StatusChip tone="teal" value={summary.active_assets} label="ASSETS UP" />
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
