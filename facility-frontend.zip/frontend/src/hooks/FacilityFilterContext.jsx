import { createContext, useContext, useState } from "react";

const FacilityFilterContext = createContext(null);

export function FacilityFilterProvider({ children }) {
  const [facilityId, setFacilityId] = useState(""); // "" = all facilities
  return (
    <FacilityFilterContext.Provider value={{ facilityId, setFacilityId }}>
      {children}
    </FacilityFilterContext.Provider>
  );
}

export function useFacilityFilter() {
  const ctx = useContext(FacilityFilterContext);
  if (!ctx) throw new Error("useFacilityFilter must be used within FacilityFilterProvider");
  return ctx;
}
