import { Building2, ShieldAlert, Wrench, Users, IndianRupee } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import KpiCard from "../components/KpiCard";
import StatusPill from "../components/StatusPill";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { endpoints } from "../api/client";
import { formatNumber, formatCompactCurrency, formatDateTime } from "../utils/format";

export default function Overview() {
  const { data: summary, loading: sLoading, error: sError } = useFetch(endpoints.dashboardSummary, []);
  const { data: activity, loading: aLoading } = useFetch(endpoints.recentActivity, []);
  const { data: energyTrend, loading: eLoading } = useFetch(endpoints.energyTrend, []);
  const { data: costTrend, loading: cLoading } = useFetch(endpoints.costTrend, []);
  const { data: facilities, loading: fLoading } = useFetch(endpoints.facilityOverview, []);

  if (sError) {
    return (
      <Layout title="Overview" subtitle="Portfolio-wide operational status">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout title="Overview" subtitle="Portfolio-wide operational status across 20 facilities">
      {/* KPI rail */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        <KpiCard
          label="Facilities"
          value={summary?.total_facilities}
          icon={Building2}
          rail="teal"
          sublabel={`${formatNumber(summary?.total_floors)} floors total`}
          loading={sLoading}
        />
        <KpiCard
          label="Active Alerts"
          value={summary?.active_alerts}
          icon={ShieldAlert}
          rail="amber"
          sublabel={`${summary?.high_priority_alerts ?? 0} high priority`}
          loading={sLoading}
        />
        <KpiCard
          label="Open Security Events"
          value={summary?.open_security_events}
          icon={ShieldAlert}
          rail="red"
          sublabel={`${summary?.high_severity_events ?? 0} high severity`}
          loading={sLoading}
        />
        <KpiCard
          label="Pending Maintenance"
          value={summary?.pending_maintenance}
          icon={Wrench}
          rail="amber"
          sublabel={formatCompactCurrency(summary?.maintenance_cost_total) + " total cost"}
          loading={sLoading}
        />
        <KpiCard
          label="Avg Occupancy"
          value={summary?.avg_occupancy}
          icon={Users}
          rail="indigo"
          sublabel="people per reading"
          loading={sLoading}
        />
        <KpiCard
          label="Total Cost"
          value={formatCompactCurrency(summary?.total_cost)}
          icon={IndianRupee}
          rail="teal"
          sublabel="energy + maintenance + water"
          loading={sLoading}
        />
      </div>

      {/* Trend charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 mb-6">
        <Panel title="Energy Consumption" subtitle="Daily total across all facilities (kWh)" rail="teal">
          {eLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={energyTrend}>
                <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
                <XAxis dataKey="day" tick={axisTickStyle} tickFormatter={(d) => d.slice(5)} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
                <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={45} />
                <Tooltip content={<ChartTooltip formatter={(v) => `${formatNumber(v)} kWh`} />} />
                <Legend wrapperStyle={{ fontSize: 11, color: CHART_COLORS.axis }} />
                <Line type="monotone" dataKey="electricity_kwh" name="Electricity" stroke={CHART_COLORS.teal} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="hvac_kwh" name="HVAC" stroke={CHART_COLORS.amber} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="lighting_kwh" name="Lighting" stroke={CHART_COLORS.indigo} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </Panel>

        <Panel title="Cost Breakdown" subtitle="Monthly spend across all facilities (\u20b9)" rail="indigo">
          {cLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={costTrend}>
                <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
                <XAxis dataKey="month" tick={axisTickStyle} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
                <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={55} tickFormatter={(v) => formatCompactCurrency(v)} />
                <Tooltip content={<ChartTooltip formatter={(v) => formatCompactCurrency(v)} />} />
                <Legend wrapperStyle={{ fontSize: 11, color: CHART_COLORS.axis }} />
                <Bar dataKey="energy_cost" name="Energy" stackId="c" fill={CHART_COLORS.teal} radius={[0, 0, 0, 0]} />
                <Bar dataKey="maintenance_cost" name="Maintenance" stackId="c" fill={CHART_COLORS.amber} />
                <Bar dataKey="water_cost" name="Water" stackId="c" fill={CHART_COLORS.indigo} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>
      </div>

      {/* Recent activity */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 mb-6">
        <Panel title="Active Alerts" subtitle="Most recent, unresolved" rail="amber">
          {aLoading ? (
            <LoadingBlock />
          ) : (
            <ul className="divide-y divide-hairline/60 -mx-5">
              {activity?.alerts.map((a) => (
                <li key={a.alert_id} className="px-5 py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm text-ink truncate">{a.alert_type}</div>
                    <div className="text-xs text-ink-dim mt-0.5">
                      {a.facility_id} \u00b7 {formatDateTime(a.created_at)}
                    </div>
                  </div>
                  <StatusPill value={a.priority} />
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Open Security Events" subtitle="Most recent, unresolved" rail="red">
          {aLoading ? (
            <LoadingBlock />
          ) : (
            <ul className="divide-y divide-hairline/60 -mx-5">
              {activity?.security_events.map((e) => (
                <li key={e.event_id} className="px-5 py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-sm text-ink truncate">{e.event_type}</div>
                    <div className="text-xs text-ink-dim mt-0.5">
                      {e.facility_id} \u00b7 {formatDateTime(e.event_time)}
                    </div>
                  </div>
                  <StatusPill value={e.severity} />
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      {/* Facility snapshot table */}
      <Panel title="Facility Snapshot" subtitle="Electricity, cost, alerts and open events by site" rail="dim">
        {fLoading ? (
          <LoadingBlock />
        ) : (
          <DataTable
            columns={[
              { key: "facility_name", header: "Facility", render: (r) => (
                  <div>
                    <div className="text-ink">{r.facility_name}</div>
                    <div className="text-xs text-ink-dim">{r.city}, {r.state}</div>
                  </div>
                ) },
              { key: "facility_type", header: "Type" },
              { key: "total_electricity_kwh", header: "Electricity", render: (r) => `${formatNumber(r.total_electricity_kwh)} kWh` },
              { key: "total_cost", header: "Total Cost", render: (r) => formatCompactCurrency(r.total_cost) },
              { key: "active_alerts", header: "Active Alerts", render: (r) => (
                  <span className={r.active_alerts > 0 ? "text-signal-amber" : "text-ink-dim"}>{r.active_alerts}</span>
                ) },
              { key: "open_security_events", header: "Open Events", render: (r) => (
                  <span className={r.open_security_events > 0 ? "text-signal-red" : "text-ink-dim"}>{r.open_security_events}</span>
                ) },
              { key: "total_assets", header: "Assets" },
            ]}
            rows={facilities}
          />
        )}
      </Panel>
    </Layout>
  );
}
