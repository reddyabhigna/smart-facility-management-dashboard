import { useMemo, useState } from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";
import { endpoints } from "../api/client";
import { formatNumber, formatCompactCurrency } from "../utils/format";

export default function Facilities() {
  const { facilityId } = useFacilityFilter();
  const { data: rows, loading, error } = useFetch(endpoints.facilityOverview, []);
  const { data: types } = useFetch(endpoints.facilityTypes, []);

  const [type, setType] = useState("");
  const [city, setCity] = useState("");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    if (!rows) return [];
    return rows.filter((r) => {
      if (facilityId && r.facility_id !== facilityId) return false;
      if (type && r.facility_type !== type) return false;
      if (city && r.city !== city) return false;
      if (search && !r.facility_name.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [rows, facilityId, type, city, search]);

  const topByCost = useMemo(() => {
    if (!rows) return [];
    return [...rows].sort((a, b) => b.total_cost - a.total_cost).slice(0, 8);
  }, [rows]);

  if (error) {
    return (
      <Layout title="Facilities" subtitle="Directory of every managed site">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout title="Facilities" subtitle={`Directory of every managed site${facilityId ? " \u00b7 filtered to 1 facility" : ""}`}>
      <Panel title="Top Facilities by Total Cost" rail="teal" className="mb-5">
        {loading ? (
          <LoadingBlock />
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={topByCost} layout="vertical" margin={{ left: 12 }}>
              <CartesianGrid stroke={CHART_COLORS.grid} horizontal={false} />
              <XAxis type="number" tick={axisTickStyle} axisLine={false} tickLine={false} tickFormatter={(v) => formatCompactCurrency(v)} />
              <YAxis type="category" dataKey="facility_name" tick={axisTickStyle} axisLine={false} tickLine={false} width={110} />
              <Tooltip content={<ChartTooltip formatter={(v) => formatCompactCurrency(v)} />} />
              <Bar dataKey="total_cost" name="Total Cost" fill={CHART_COLORS.teal} radius={[0, 3, 3, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Panel>

      <Panel
        title="All Facilities"
        subtitle={`${filtered.length} of ${rows?.length ?? 0} sites`}
        rail="dim"
        action={
          <div className="flex items-center gap-2 flex-wrap">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name\u2026"
              className="bg-panel-raised border border-hairline rounded-md text-xs text-ink-muted px-2.5 py-1.5 w-32 focus:outline-none focus:border-signal-teal/50"
            />
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="bg-panel-raised border border-hairline rounded-md text-xs text-ink-muted px-2.5 py-1.5 focus:outline-none focus:border-signal-teal/50"
            >
              <option value="">All types</option>
              {types?.facility_types.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <select
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="bg-panel-raised border border-hairline rounded-md text-xs text-ink-muted px-2.5 py-1.5 focus:outline-none focus:border-signal-teal/50"
            >
              <option value="">All cities</option>
              {types?.cities.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        }
      >
        {loading ? (
          <LoadingBlock />
        ) : (
          <DataTable
            columns={[
              { key: "facility_id", header: "ID" },
              { key: "facility_name", header: "Name" },
              { key: "facility_type", header: "Type" },
              { key: "city", header: "City", render: (r) => `${r.city}, ${r.state}` },
              { key: "total_floors", header: "Floors" },
              { key: "total_area_sqft", header: "Area (sqft)", render: (r) => formatNumber(r.total_area_sqft) },
              { key: "total_assets", header: "Assets" },
              { key: "total_cost", header: "Total Cost", render: (r) => formatCompactCurrency(r.total_cost) },
              { key: "active_alerts", header: "Alerts", render: (r) => (
                  <span className={r.active_alerts > 0 ? "text-signal-amber" : "text-ink-dim"}>{r.active_alerts}</span>
                ) },
            ]}
            rows={filtered}
          />
        )}
      </Panel>
    </Layout>
  );
}
