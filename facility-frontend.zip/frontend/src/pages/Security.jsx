import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { ShieldAlert, Bell, AlertOctagon, Flame } from "lucide-react";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import KpiCard from "../components/KpiCard";
import StatusPill from "../components/StatusPill";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";
import { endpoints } from "../api/client";
import { formatDateTime } from "../utils/format";

export default function Security() {
  const { facilityId } = useFacilityFilter();
  const params = facilityId ? { facility_id: facilityId } : {};

  const { data: secSummary, loading: sLoading, error } = useFetch(endpoints.securitySummary, []);
  const { data: alertSummary, loading: alLoading } = useFetch(endpoints.alertsSummary, []);
  const { data: events, loading: eLoading } = useFetch(() => endpoints.securityEvents(params), [facilityId]);
  const { data: alerts, loading: aLoading } = useFetch(() => endpoints.alerts(params), [facilityId]);

  if (error) {
    return (
      <Layout title="Security & Alerts" subtitle="Live events and system-raised alerts">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout
      title="Security & Alerts"
      subtitle={`Live events and system-raised alerts${facilityId ? " \u00b7 filtered to 1 facility" : ""}`}
    >
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Open Events" value={secSummary?.open_count} icon={ShieldAlert} rail="red" loading={sLoading} />
        <KpiCard
          label="High Severity"
          value={secSummary?.by_severity.find((s) => s.severity === "High")?.count ?? 0}
          icon={Flame}
          rail="red"
          loading={sLoading}
        />
        <KpiCard label="Active Alerts" value={alertSummary?.active_count} icon={Bell} rail="amber" loading={alLoading} />
        <KpiCard
          label="High Priority"
          value={alertSummary?.by_priority.find((p) => p.priority === "High")?.count ?? 0}
          icon={AlertOctagon}
          rail="amber"
          loading={alLoading}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 mb-6">
        <Panel title="Security Events by Type" subtitle="All facilities" rail="red">
          {sLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={secSummary?.by_type}>
                <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
                <XAxis dataKey="event_type" tick={{ ...axisTickStyle, fontSize: 10 }} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} interval={0} angle={-20} textAnchor="end" height={60} />
                <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={30} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="count" name="Events" fill={CHART_COLORS.red} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>

        <Panel title="Alerts by Type" subtitle="All facilities" rail="amber">
          {alLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={alertSummary?.by_type}>
                <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
                <XAxis dataKey="alert_type" tick={{ ...axisTickStyle, fontSize: 10 }} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} interval={0} angle={-20} textAnchor="end" height={60} />
                <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={30} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="count" name="Alerts" fill={CHART_COLORS.amber} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <Panel title="Security Events" subtitle={`${events?.length ?? 0} records`} rail="dim">
          {eLoading ? (
            <LoadingBlock />
          ) : (
            <DataTable
              columns={[
                { key: "event_type", header: "Event" },
                { key: "facility_id", header: "Facility" },
                { key: "severity", header: "Severity", render: (r) => <StatusPill value={r.severity} /> },
                { key: "status", header: "Status", render: (r) => <StatusPill value={r.status} /> },
                { key: "event_time", header: "Time", render: (r) => formatDateTime(r.event_time) },
              ]}
              rows={events}
            />
          )}
        </Panel>

        <Panel title="Alerts" subtitle={`${alerts?.length ?? 0} records`} rail="dim">
          {aLoading ? (
            <LoadingBlock />
          ) : (
            <DataTable
              columns={[
                { key: "alert_type", header: "Alert" },
                { key: "facility_id", header: "Facility" },
                { key: "priority", header: "Priority", render: (r) => <StatusPill value={r.priority} /> },
                { key: "status", header: "Status", render: (r) => <StatusPill value={r.status} /> },
                { key: "created_at", header: "Raised", render: (r) => formatDateTime(r.created_at) },
              ]}
              rows={alerts}
            />
          )}
        </Panel>
      </div>
    </Layout>
  );
}
