import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Cpu, CheckCircle2, Wrench, Clock } from "lucide-react";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import KpiCard from "../components/KpiCard";
import StatusPill from "../components/StatusPill";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";
import { endpoints } from "../api/client";
import { formatCompactCurrency, formatDate } from "../utils/format";

// Reshape [{asset_type, status, count}] into one row per type with a column per status,
// which is what recharts needs for a grouped bar chart.
function pivotByType(rows) {
  if (!rows) return [];
  const byType = {};
  rows.forEach(({ asset_type, status, count }) => {
    byType[asset_type] = byType[asset_type] || { asset_type };
    byType[asset_type][status] = count;
  });
  return Object.values(byType);
}

export default function Assets() {
  const { facilityId } = useFacilityFilter();
  const params = facilityId ? { facility_id: facilityId } : {};

  const { data: statusSummary, loading: sLoading, error } = useFetch(endpoints.assetStatusSummary, []);
  const { data: maintSummary, loading: mLoading } = useFetch(endpoints.maintenanceSummary, []);
  const { data: assets, loading: aLoading } = useFetch(() => endpoints.assets(params), [facilityId]);
  const { data: maintenance, loading: rLoading } = useFetch(() => endpoints.maintenance(params), [facilityId]);

  const typeData = pivotByType(statusSummary?.by_type);
  const activeTotal = statusSummary?.by_status.find((s) => s.status === "Active")?.count ?? 0;
  const maintTotal = statusSummary?.by_status.find((s) => s.status === "Maintenance")?.count ?? 0;
  const inactiveTotal = statusSummary?.by_status.find((s) => s.status === "Inactive")?.count ?? 0;

  if (error) {
    return (
      <Layout title="Assets & Maintenance" subtitle="Equipment health and work orders">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout
      title="Assets & Maintenance"
      subtitle={`Equipment health and work orders${facilityId ? " \u00b7 filtered to 1 facility" : ""}`}
    >
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Active Assets" value={activeTotal} icon={CheckCircle2} rail="teal" loading={sLoading} />
        <KpiCard label="In Maintenance" value={maintTotal} icon={Wrench} rail="amber" loading={sLoading} />
        <KpiCard label="Inactive" value={inactiveTotal} icon={Cpu} rail="dim" loading={sLoading} />
        <KpiCard
          label="Pending Work Orders"
          value={maintSummary?.pending_count}
          icon={Clock}
          rail="red"
          sublabel={formatCompactCurrency(maintSummary?.total_cost) + " total spend"}
          loading={mLoading}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 mb-6">
        <Panel title="Asset Status by Type" rail="teal">
          {sLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={typeData}>
                <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
                <XAxis dataKey="asset_type" tick={axisTickStyle} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
                <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={30} />
                <Tooltip content={<ChartTooltip />} />
                <Legend wrapperStyle={{ fontSize: 11, color: CHART_COLORS.axis }} />
                <Bar dataKey="Active" stackId="s" fill={CHART_COLORS.teal} />
                <Bar dataKey="Maintenance" stackId="s" fill={CHART_COLORS.amber} />
                <Bar dataKey="Inactive" stackId="s" fill={CHART_COLORS.grid} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>

        <Panel title="Maintenance Cost by Issue" rail="amber">
          {mLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={maintSummary?.by_issue} layout="vertical" margin={{ left: 8 }}>
                <CartesianGrid stroke={CHART_COLORS.grid} horizontal={false} />
                <XAxis type="number" tick={axisTickStyle} axisLine={false} tickLine={false} tickFormatter={(v) => formatCompactCurrency(v)} />
                <YAxis type="category" dataKey="issue" tick={axisTickStyle} axisLine={false} tickLine={false} width={110} />
                <Tooltip content={<ChartTooltip formatter={(v) => formatCompactCurrency(v)} />} />
                <Bar dataKey="cost" name="Cost" fill={CHART_COLORS.amber} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <Panel title="Assets" subtitle={`${assets?.length ?? 0} units`} rail="dim">
          {aLoading ? (
            <LoadingBlock />
          ) : (
            <DataTable
              columns={[
                { key: "asset_name", header: "Asset" },
                { key: "asset_type", header: "Type" },
                { key: "facility_id", header: "Facility" },
                { key: "status", header: "Status", render: (r) => <StatusPill value={r.status} /> },
                { key: "install_date", header: "Installed", render: (r) => formatDate(r.install_date) },
              ]}
              rows={assets}
            />
          )}
        </Panel>

        <Panel title="Maintenance Records" subtitle={`${maintenance?.length ?? 0} work orders`} rail="dim">
          {rLoading ? (
            <LoadingBlock />
          ) : (
            <DataTable
              columns={[
                { key: "issue", header: "Issue" },
                { key: "asset_id", header: "Asset" },
                { key: "technician", header: "Technician" },
                { key: "status", header: "Status", render: (r) => <StatusPill value={r.status} /> },
                { key: "cost", header: "Cost", render: (r) => formatCompactCurrency(r.cost) },
                { key: "maintenance_date", header: "Date", render: (r) => formatDate(r.maintenance_date) },
              ]}
              rows={maintenance}
            />
          )}
        </Panel>
      </div>
    </Layout>
  );
}
