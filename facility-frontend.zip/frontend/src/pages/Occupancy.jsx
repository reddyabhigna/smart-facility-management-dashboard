import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Users, TrendingUp } from "lucide-react";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import KpiCard from "../components/KpiCard";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";
import { endpoints } from "../api/client";
import { formatDateTime } from "../utils/format";

export default function Occupancy() {
  const { facilityId } = useFacilityFilter();
  const params = facilityId ? { facility_id: facilityId } : {};

  const { data: byFacility, loading: bLoading, error } = useFetch(endpoints.occupancyByFacility, []);
  const { data: byRoom, loading: rLoading } = useFetch(endpoints.occupancyByRoomType, []);
  const { data: readings, loading: readLoading } = useFetch(() => endpoints.occupancy(params), [facilityId]);

  const overallAvg = byFacility
    ? Math.round((byFacility.reduce((s, f) => s + f.avg_occupancy, 0) / byFacility.length) * 10) / 10
    : null;
  const overallPeak = byFacility ? Math.max(...byFacility.map((f) => f.peak_occupancy)) : null;

  const recentReadings = readings ? [...readings].reverse().slice(0, 15) : [];

  if (error) {
    return (
      <Layout title="Occupancy" subtitle="Foot traffic by facility and room type">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout
      title="Occupancy"
      subtitle={`Foot traffic by facility and room type${facilityId ? " \u00b7 filtered to 1 facility" : ""}`}
    >
      <div className="grid grid-cols-2 gap-4 mb-6 max-w-md">
        <KpiCard label="Portfolio Avg" value={overallAvg} unit="people" icon={Users} rail="indigo" loading={bLoading} />
        <KpiCard label="Portfolio Peak" value={overallPeak} unit="people" icon={TrendingUp} rail="teal" loading={bLoading} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 mb-6">
        <Panel title="Occupancy by Facility" subtitle="Average vs. peak headcount" rail="indigo">
          {bLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={byFacility}>
                <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
                <XAxis dataKey="facility_id" tick={axisTickStyle} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
                <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={30} />
                <Tooltip content={<ChartTooltip />} labelFormatter={(l) => byFacility?.find(f => f.facility_id === l)?.facility_name} />
                <Legend wrapperStyle={{ fontSize: 11, color: CHART_COLORS.axis }} />
                <Bar dataKey="avg_occupancy" name="Average" fill={CHART_COLORS.indigo} radius={[3, 3, 0, 0]} />
                <Bar dataKey="peak_occupancy" name="Peak" fill={CHART_COLORS.teal} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>

        <Panel title="Occupancy by Room Type" subtitle="Average headcount per reading" rail="teal">
          {rLoading ? (
            <LoadingBlock />
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={byRoom} layout="vertical" margin={{ left: 12 }}>
                <CartesianGrid stroke={CHART_COLORS.grid} horizontal={false} />
                <XAxis type="number" tick={axisTickStyle} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="room" tick={axisTickStyle} axisLine={false} tickLine={false} width={90} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="avg_occupancy" name="Avg Occupancy" fill={CHART_COLORS.teal} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Panel>
      </div>

      <Panel title="Recent Readings" subtitle="Latest 15 occupancy sensor readings" rail="dim">
        {readLoading ? (
          <LoadingBlock />
        ) : (
          <DataTable
            columns={[
              { key: "timestamp", header: "Time", render: (r) => formatDateTime(r.timestamp) },
              { key: "facility_id", header: "Facility" },
              { key: "floor", header: "Floor" },
              { key: "room", header: "Room" },
              { key: "occupancy_count", header: "Headcount" },
            ]}
            rows={recentReadings}
          />
        )}
      </Panel>
    </Layout>
  );
}
