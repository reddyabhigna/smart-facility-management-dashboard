import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";
import { Zap, Droplets, Wind, Lightbulb } from "lucide-react";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import KpiCard from "../components/KpiCard";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";
import { endpoints } from "../api/client";
import { formatNumber, formatDateTime } from "../utils/format";

export default function Energy() {
  const { facilityId } = useFacilityFilter();
  const params = facilityId ? { facility_id: facilityId } : {};

  const { data: trend, loading: tLoading, error } = useFetch(() => endpoints.energyTrend(params), [facilityId]);
  const { data: byFacility, loading: bLoading } = useFetch(endpoints.energyByFacility, []);
  const { data: readings, loading: rLoading } = useFetch(() => endpoints.energyUsage(params), [facilityId]);

  const totals = trend?.reduce(
    (acc, d) => ({
      electricity: acc.electricity + d.electricity_kwh,
      hvac: acc.hvac + d.hvac_kwh,
      lighting: acc.lighting + d.lighting_kwh,
      water: acc.water + d.water_liters,
    }),
    { electricity: 0, hvac: 0, lighting: 0, water: 0 }
  );

  const recentReadings = readings ? [...readings].reverse().slice(0, 15) : [];

  if (error) {
    return (
      <Layout title="Energy & Water" subtitle="Consumption across electricity, HVAC, lighting and water">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout
      title="Energy & Water"
      subtitle={`Consumption across electricity, HVAC, lighting and water${facilityId ? " \u00b7 filtered to 1 facility" : ""}`}
    >
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Electricity" value={formatNumber(totals?.electricity)} unit="kWh" icon={Zap} rail="teal" loading={tLoading} />
        <KpiCard label="HVAC" value={formatNumber(totals?.hvac)} unit="kWh" icon={Wind} rail="amber" loading={tLoading} />
        <KpiCard label="Lighting" value={formatNumber(totals?.lighting)} unit="kWh" icon={Lightbulb} rail="indigo" loading={tLoading} />
        <KpiCard label="Water" value={formatNumber(totals?.water)} unit="litres" icon={Droplets} rail="teal" loading={tLoading} />
      </div>

      <Panel title="Consumption Trend" subtitle="Daily totals (kWh)" rail="teal" className="mb-5">
        {tLoading ? (
          <LoadingBlock />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={trend}>
              <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
              <XAxis dataKey="day" tick={axisTickStyle} tickFormatter={(d) => d.slice(5)} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
              <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={45} />
              <Tooltip content={<ChartTooltip formatter={(v) => `${formatNumber(v)} kWh`} />} />
              <Legend wrapperStyle={{ fontSize: 11, color: CHART_COLORS.axis }} />
              <Line type="monotone" dataKey="electricity_kwh" name="Electricity" stroke={CHART_COLORS.teal} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="hvac_kwh" name="HVAC" stroke={CHART_COLORS.amber} strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="lighting_kwh" name="Lighting" stroke={CHART_COLORS.indigo} strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </Panel>

      <Panel title="Electricity by Facility" subtitle="Total kWh, all facilities" rail="indigo" className="mb-5">
        {bLoading ? (
          <LoadingBlock />
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={byFacility}>
              <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
              <XAxis dataKey="facility_id" tick={axisTickStyle} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
              <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={45} />
              <Tooltip content={<ChartTooltip formatter={(v) => `${formatNumber(v)} kWh`} />} labelFormatter={(l) => byFacility?.find(f => f.facility_id === l)?.facility_name} />
              <Bar dataKey="electricity_kwh" name="Electricity" fill={CHART_COLORS.teal} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Panel>

      <Panel title="Recent Readings" subtitle="Latest 15 hourly meter readings" rail="dim">
        {rLoading ? (
          <LoadingBlock />
        ) : (
          <DataTable
            columns={[
              { key: "timestamp", header: "Time", render: (r) => formatDateTime(r.timestamp) },
              { key: "facility_id", header: "Facility" },
              { key: "electricity_kwh", header: "Electricity (kWh)" },
              { key: "hvac_kwh", header: "HVAC (kWh)" },
              { key: "lighting_kwh", header: "Lighting (kWh)" },
              { key: "water_liters", header: "Water (L)", render: (r) => formatNumber(r.water_liters) },
            ]}
            rows={recentReadings}
          />
        )}
      </Panel>
    </Layout>
  );
}
