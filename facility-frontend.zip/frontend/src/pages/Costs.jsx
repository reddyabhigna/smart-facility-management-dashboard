import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { IndianRupee, Zap, Wrench, Droplets } from "lucide-react";
import Layout from "../components/Layout";
import Panel from "../components/Panel";
import KpiCard from "../components/KpiCard";
import DataTable from "../components/DataTable";
import { LoadingBlock, ErrorBlock } from "../components/States";
import { CHART_COLORS, axisTickStyle, ChartTooltip } from "../components/ChartTheme";
import { useFetch } from "../hooks/useFetch";
import { useFacilityFilter } from "../hooks/FacilityFilterContext";
import { endpoints } from "../api/client";
import { formatCompactCurrency } from "../utils/format";

export default function Costs() {
  const { facilityId } = useFacilityFilter();
  const params = facilityId ? { facility_id: facilityId } : {};

  const { data: trend, loading: tLoading, error } = useFetch(endpoints.costTrend, []);
  const { data: byFacility, loading: bLoading } = useFetch(endpoints.costByFacility, []);
  const { data: reports, loading: rLoading } = useFetch(() => endpoints.costReports(params), [facilityId]);

  const totals = trend?.reduce(
    (acc, m) => ({
      energy: acc.energy + m.energy_cost,
      maintenance: acc.maintenance + m.maintenance_cost,
      water: acc.water + m.water_cost,
      total: acc.total + m.total_cost,
    }),
    { energy: 0, maintenance: 0, water: 0, total: 0 }
  );

  if (error) {
    return (
      <Layout title="Cost Reports" subtitle="Spend across energy, maintenance and water">
        <ErrorBlock />
      </Layout>
    );
  }

  return (
    <Layout
      title="Cost Reports"
      subtitle={`Spend across energy, maintenance and water${facilityId ? " \u00b7 filtered to 1 facility" : ""}`}
    >
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <KpiCard label="Total Cost" value={formatCompactCurrency(totals?.total)} icon={IndianRupee} rail="teal" loading={tLoading} />
        <KpiCard label="Energy" value={formatCompactCurrency(totals?.energy)} icon={Zap} rail="amber" loading={tLoading} />
        <KpiCard label="Maintenance" value={formatCompactCurrency(totals?.maintenance)} icon={Wrench} rail="indigo" loading={tLoading} />
        <KpiCard label="Water" value={formatCompactCurrency(totals?.water)} icon={Droplets} rail="teal" loading={tLoading} />
      </div>

      <Panel title="Monthly Cost Trend" subtitle="All facilities combined" rail="teal" className="mb-5">
        {tLoading ? (
          <LoadingBlock />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={trend}>
              <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
              <XAxis dataKey="month" tick={axisTickStyle} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
              <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={55} tickFormatter={(v) => formatCompactCurrency(v)} />
              <Tooltip content={<ChartTooltip formatter={(v) => formatCompactCurrency(v)} />} />
              <Legend wrapperStyle={{ fontSize: 11, color: CHART_COLORS.axis }} />
              <Bar dataKey="energy_cost" name="Energy" stackId="c" fill={CHART_COLORS.teal} />
              <Bar dataKey="maintenance_cost" name="Maintenance" stackId="c" fill={CHART_COLORS.amber} />
              <Bar dataKey="water_cost" name="Water" stackId="c" fill={CHART_COLORS.indigo} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Panel>

      <Panel title="Cost by Facility" subtitle="Total spend, all months" rail="indigo" className="mb-5">
        {bLoading ? (
          <LoadingBlock />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={byFacility}>
              <CartesianGrid stroke={CHART_COLORS.grid} vertical={false} />
              <XAxis dataKey="facility_id" tick={axisTickStyle} axisLine={{ stroke: CHART_COLORS.grid }} tickLine={false} />
              <YAxis tick={axisTickStyle} axisLine={false} tickLine={false} width={55} tickFormatter={(v) => formatCompactCurrency(v)} />
              <Tooltip content={<ChartTooltip formatter={(v) => formatCompactCurrency(v)} />} labelFormatter={(l) => byFacility?.find(f => f.facility_id === l)?.facility_name} />
              <Bar dataKey="total_cost" name="Total Cost" fill={CHART_COLORS.indigo} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Panel>

      <Panel title="Cost Report Records" subtitle={`${reports?.length ?? 0} monthly reports`} rail="dim">
        {rLoading ? (
          <LoadingBlock />
        ) : (
          <DataTable
            columns={[
              { key: "facility_id", header: "Facility" },
              { key: "month", header: "Month" },
              { key: "energy_cost", header: "Energy", render: (r) => formatCompactCurrency(r.energy_cost) },
              { key: "maintenance_cost", header: "Maintenance", render: (r) => formatCompactCurrency(r.maintenance_cost) },
              { key: "water_cost", header: "Water", render: (r) => formatCompactCurrency(r.water_cost) },
              { key: "total_cost", header: "Total", render: (r) => formatCompactCurrency(r.total_cost) },
            ]}
            rows={reports}
          />
        )}
      </Panel>
    </Layout>
  );
}
