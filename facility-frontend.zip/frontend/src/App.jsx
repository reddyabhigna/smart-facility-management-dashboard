import { BrowserRouter, Routes, Route } from "react-router-dom";
import { FacilityFilterProvider } from "./hooks/FacilityFilterContext";
import Overview from "./pages/Overview";
import Facilities from "./pages/Facilities";
import Energy from "./pages/Energy";
import Assets from "./pages/Assets";
import Occupancy from "./pages/Occupancy";
import Security from "./pages/Security";
import Costs from "./pages/Costs";

export default function App() {
  return (
    <FacilityFilterProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Overview />} />
          <Route path="/facilities" element={<Facilities />} />
          <Route path="/energy" element={<Energy />} />
          <Route path="/assets" element={<Assets />} />
          <Route path="/occupancy" element={<Occupancy />} />
          <Route path="/security" element={<Security />} />
          <Route path="/costs" element={<Costs />} />
        </Routes>
      </BrowserRouter>
    </FacilityFilterProvider>
  );
}
