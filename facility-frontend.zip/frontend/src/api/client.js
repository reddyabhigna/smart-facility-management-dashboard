import axios from "axios";

// Override with a .env file (VITE_API_BASE_URL=...) when deploying the backend elsewhere.
const baseURL = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

export const api = axios.create({ baseURL });

export const endpoints = {
  dashboardSummary: () => api.get("/api/dashboard/summary"),
  recentActivity: () => api.get("/api/dashboard/recent-activity"),
  facilityOverview: () => api.get("/api/dashboard/facility-overview"),

  facilities: (params) => api.get("/api/facilities", { params }),
  facilityTypes: () => api.get("/api/facilities/types"),

  energyUsage: (params) => api.get("/api/energy", { params }),
  energyTrend: (params) => api.get("/api/energy/trend", { params }),
  energyByFacility: () => api.get("/api/energy/by-facility"),

  assets: (params) => api.get("/api/assets", { params }),
  assetStatusSummary: () => api.get("/api/assets/status-summary"),

  maintenance: (params) => api.get("/api/maintenance", { params }),
  maintenanceSummary: () => api.get("/api/maintenance/summary"),

  occupancy: (params) => api.get("/api/occupancy", { params }),
  occupancyByFacility: () => api.get("/api/occupancy/by-facility"),
  occupancyByRoomType: () => api.get("/api/occupancy/by-room-type"),

  securityEvents: (params) => api.get("/api/security-events", { params }),
  securitySummary: () => api.get("/api/security-events/summary"),

  alerts: (params) => api.get("/api/alerts", { params }),
  alertsSummary: () => api.get("/api/alerts/summary"),

  costReports: (params) => api.get("/api/cost-reports", { params }),
  costTrend: () => api.get("/api/cost-reports/trend"),
  costByFacility: () => api.get("/api/cost-reports/by-facility"),
};
