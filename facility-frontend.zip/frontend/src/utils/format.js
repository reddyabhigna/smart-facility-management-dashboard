export function formatNumber(n, decimals = 0) {
  if (n === null || n === undefined || Number.isNaN(n)) return "\u2014";
  return Number(n).toLocaleString("en-IN", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatCurrency(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return "\u2014";
  return "\u20b9" + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export function formatCompactCurrency(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return "\u2014";
  const abs = Math.abs(n);
  if (abs >= 1e7) return "\u20b9" + (n / 1e7).toFixed(2) + "Cr";
  if (abs >= 1e5) return "\u20b9" + (n / 1e5).toFixed(2) + "L";
  if (abs >= 1e3) return "\u20b9" + (n / 1e3).toFixed(1) + "k";
  return "\u20b9" + formatNumber(n);
}

export function formatDateTime(iso) {
  if (!iso) return "\u2014";
  const d = new Date(iso);
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatDate(iso) {
  if (!iso) return "\u2014";
  const d = new Date(iso);
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
