from fastapi import APIRouter
from app.data_store import get_store
from app.utils import to_records

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary")
def dashboard_summary():
    """One call, every headline KPI -- powers the overview page's stat cards."""
    s = get_store()
    facilities = s.df("facilities")
    energy = s.df("energy_usage")
    assets = s.df("assets")
    maintenance = s.df("maintenance_records")
    occupancy = s.df("occupancy")
    security = s.df("security_events")
    alerts = s.df("alerts")
    costs = s.df("cost_reports")

    return {
        "total_facilities": int(facilities.shape[0]),
        "total_floors": int(facilities["total_floors"].sum()),
        "total_area_sqft": int(facilities["total_area_sqft"].sum()),
        "total_electricity_kwh": float(energy["electricity_kwh"].sum()),
        "total_water_liters": float(energy["water_liters"].sum()),
        "total_assets": int(assets.shape[0]),
        "active_assets": int((assets["status"] == "Active").sum()),
        "assets_in_maintenance": int((assets["status"] == "Maintenance").sum()),
        "pending_maintenance": int((maintenance["status"] == "Pending").sum()),
        "maintenance_cost_total": float(maintenance["cost"].sum()),
        "avg_occupancy": round(float(occupancy["occupancy_count"].mean()), 1),
        "open_security_events": int((security["status"] == "Open").sum()),
        "high_severity_events": int((security["severity"] == "High").sum()),
        "active_alerts": int((alerts["status"] == "Active").sum()),
        "high_priority_alerts": int(
            ((alerts["priority"] == "High") & (alerts["status"] == "Active")).sum()
        ),
        "total_cost": float(costs["total_cost"].sum()),
        "total_energy_cost": float(costs["energy_cost"].sum()),
        "total_maintenance_cost": float(costs["maintenance_cost"].sum()),
        "total_water_cost": float(costs["water_cost"].sum()),
    }


@router.get("/recent-activity")
def recent_activity():
    """Latest active alerts + open security events -- powers the overview feed."""
    s = get_store()
    alerts = s.df("alerts")
    alerts = alerts[alerts["status"] == "Active"].sort_values("created_at", ascending=False).head(6)

    events = s.df("security_events")
    events = events[events["status"] == "Open"].sort_values("event_time", ascending=False).head(6)

    return {
        "alerts": to_records(alerts),
        "security_events": to_records(events),
    }


@router.get("/facility-overview")
def facility_overview():
    """Per-facility rollup joining every sheet -- powers the facilities table."""
    s = get_store()
    facilities = s.df("facilities")
    energy = s.df("energy_usage").groupby("facility_id")["electricity_kwh"].sum().reset_index(
        name="total_electricity_kwh"
    )
    costs = s.df("cost_reports").groupby("facility_id")["total_cost"].sum().reset_index(
        name="total_cost"
    )
    alerts = s.df("alerts")
    alerts = alerts[alerts["status"] == "Active"].groupby("facility_id").size().reset_index(
        name="active_alerts"
    )
    events = s.df("security_events")
    events = events[events["status"] == "Open"].groupby("facility_id").size().reset_index(
        name="open_security_events"
    )
    assets = s.df("assets").groupby("facility_id").size().reset_index(name="total_assets")

    out = facilities.merge(energy, on="facility_id", how="left")
    out = out.merge(costs, on="facility_id", how="left")
    out = out.merge(alerts, on="facility_id", how="left")
    out = out.merge(events, on="facility_id", how="left")
    out = out.merge(assets, on="facility_id", how="left")
    out = out.fillna(0)
    for col in ["total_electricity_kwh", "total_cost", "active_alerts", "open_security_events", "total_assets"]:
        out[col] = out[col].astype(float) if col in ("total_electricity_kwh", "total_cost") else out[col].astype(int)

    return to_records(out)
