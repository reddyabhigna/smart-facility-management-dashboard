from fastapi import APIRouter, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/maintenance", tags=["maintenance"])


@router.get("")
def list_maintenance(
    facility_id: str | None = Query(None),
    status: str | None = Query(None),
    technician: str | None = Query(None),
):
    df = get_store().df("maintenance_records")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_filter(df, "status", status)
    df = apply_filter(df, "technician", technician)
    return to_records(df.sort_values("maintenance_date", ascending=False))


@router.get("/summary")
def maintenance_summary():
    """Status breakdown + cost by issue type -- powers the maintenance panel."""
    df = get_store().df("maintenance_records")
    by_status = df.groupby("status").agg(count=("maintenance_id", "size"), cost=("cost", "sum")).reset_index()
    by_issue = df.groupby("issue").agg(count=("maintenance_id", "size"), cost=("cost", "sum")).reset_index()
    return {
        "by_status": by_status.to_dict(orient="records"),
        "by_issue": by_issue.sort_values("cost", ascending=False).to_dict(orient="records"),
        "total_cost": float(df["cost"].sum()),
        "pending_count": int((df["status"] == "Pending").sum()),
    }
