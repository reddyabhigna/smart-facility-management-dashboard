from fastapi import APIRouter, HTTPException, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/facilities", tags=["facilities"])


@router.get("")
def list_facilities(
    facility_type: str | None = Query(None),
    city: str | None = Query(None),
    state: str | None = Query(None),
):
    df = get_store().df("facilities")
    df = apply_filter(df, "facility_type", facility_type)
    df = apply_filter(df, "city", city)
    df = apply_filter(df, "state", state)
    return to_records(df)


@router.get("/types")
def facility_types():
    """Distinct facility types + cities/states -- used to populate filter dropdowns."""
    df = get_store().df("facilities")
    return {
        "facility_types": sorted(df["facility_type"].unique().tolist()),
        "cities": sorted(df["city"].unique().tolist()),
        "states": sorted(df["state"].unique().tolist()),
    }


@router.get("/{facility_id}")
def get_facility(facility_id: str):
    df = get_store().df("facilities")
    row = df[df["facility_id"] == facility_id]
    if row.empty:
        raise HTTPException(status_code=404, detail=f"Facility '{facility_id}' not found")
    return to_records(row)[0]
