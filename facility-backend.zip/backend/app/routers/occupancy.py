from fastapi import APIRouter, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/occupancy", tags=["occupancy"])


@router.get("")
def list_occupancy(
    facility_id: str | None = Query(None),
    room: str | None = Query(None),
):
    df = get_store().df("occupancy")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_filter(df, "room", room)
    return to_records(df.sort_values("timestamp"))


@router.get("/by-facility")
def occupancy_by_facility():
    """Average + peak occupancy per facility -- powers the occupancy bar chart."""
    df = get_store().df("occupancy")
    fac = get_store().df("facilities")[["facility_id", "facility_name"]]
    grouped = (
        df.groupby("facility_id")["occupancy_count"]
        .agg(avg_occupancy="mean", peak_occupancy="max")
        .reset_index()
    )
    grouped["avg_occupancy"] = grouped["avg_occupancy"].round(1)
    grouped = grouped.merge(fac, on="facility_id", how="left")
    return grouped.to_dict(orient="records")


@router.get("/by-room-type")
def occupancy_by_room_type():
    """Average occupancy per room type -- powers the room-type breakdown chart."""
    df = get_store().df("occupancy")
    grouped = df.groupby("room")["occupancy_count"].agg(avg_occupancy="mean", total="sum").reset_index()
    grouped["avg_occupancy"] = grouped["avg_occupancy"].round(1)
    return grouped.sort_values("total", ascending=False).to_dict(orient="records")
