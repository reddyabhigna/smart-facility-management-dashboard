from fastapi import APIRouter, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("")
def list_alerts(
    facility_id: str | None = Query(None),
    priority: str | None = Query(None),
    status: str | None = Query(None),
):
    df = get_store().df("alerts")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_filter(df, "priority", priority)
    df = apply_filter(df, "status", status)
    return to_records(df.sort_values("created_at", ascending=False))


@router.get("/summary")
def alerts_summary():
    """Counts by priority/type/status -- powers the alerts overview panel."""
    df = get_store().df("alerts")
    return {
        "by_priority": df.groupby("priority").size().reset_index(name="count").to_dict(orient="records"),
        "by_type": df.groupby("alert_type").size().reset_index(name="count").to_dict(orient="records"),
        "active_count": int((df["status"] == "Active").sum()),
    }
