from fastapi import APIRouter, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/cost-reports", tags=["costs"])


@router.get("")
def list_cost_reports(
    facility_id: str | None = Query(None),
    month: str | None = Query(None),
):
    df = get_store().df("cost_reports")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_filter(df, "month", month)
    df = df.sort_values("month_period")
    df = df.drop(columns=["month_period"])
    return to_records(df)


@router.get("/trend")
def cost_trend():
    """Total cost by month across all facilities -- powers the cost trend chart."""
    df = get_store().df("cost_reports")
    grouped = (
        df.groupby(["month_period", "month"])[["energy_cost", "maintenance_cost", "water_cost", "total_cost"]]
        .sum()
        .reset_index()
        .sort_values("month_period")
        .drop(columns=["month_period"])
    )
    return grouped.to_dict(orient="records")


@router.get("/by-facility")
def cost_by_facility():
    """Total cost per facility -- powers the cost-by-facility bar chart."""
    df = get_store().df("cost_reports")
    fac = get_store().df("facilities")[["facility_id", "facility_name"]]
    grouped = (
        df.groupby("facility_id")[["energy_cost", "maintenance_cost", "water_cost", "total_cost"]]
        .sum()
        .reset_index()
    )
    grouped = grouped.merge(fac, on="facility_id", how="left")
    return grouped.sort_values("total_cost", ascending=False).to_dict(orient="records")
