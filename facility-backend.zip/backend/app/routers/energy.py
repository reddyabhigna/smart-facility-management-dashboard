from fastapi import APIRouter, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter, apply_date_range

router = APIRouter(prefix="/api/energy", tags=["energy"])


@router.get("")
def list_energy_usage(
    facility_id: str | None = Query(None),
    start: str | None = Query(None),
    end: str | None = Query(None),
):
    df = get_store().df("energy_usage")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_date_range(df, "timestamp", start, end)
    return to_records(df.sort_values("timestamp"))


@router.get("/trend")
def energy_trend(facility_id: str | None = Query(None)):
    """Hourly readings bucketed by day -- powers the energy trend line chart."""
    df = get_store().df("energy_usage")
    df = apply_filter(df, "facility_id", facility_id)
    df["day"] = df["timestamp"].dt.strftime("%Y-%m-%d")
    grouped = (
        df.groupby("day")[["electricity_kwh", "hvac_kwh", "lighting_kwh", "water_liters"]]
        .sum()
        .reset_index()
        .sort_values("day")
    )
    return grouped.to_dict(orient="records")


@router.get("/by-facility")
def energy_by_facility():
    """Total consumption per facility -- powers facility comparison bar chart."""
    df = get_store().df("energy_usage")
    fac = get_store().df("facilities")[["facility_id", "facility_name"]]
    grouped = (
        df.groupby("facility_id")[["electricity_kwh", "hvac_kwh", "lighting_kwh", "water_liters"]]
        .sum()
        .reset_index()
    )
    grouped = grouped.merge(fac, on="facility_id", how="left")
    return grouped.to_dict(orient="records")
