from fastapi import APIRouter, HTTPException, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/assets", tags=["assets"])


@router.get("")
def list_assets(
    facility_id: str | None = Query(None),
    asset_type: str | None = Query(None),
    status: str | None = Query(None),
):
    df = get_store().df("assets")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_filter(df, "asset_type", asset_type)
    df = apply_filter(df, "status", status)
    return to_records(df)


@router.get("/status-summary")
def status_summary():
    """Asset counts by status and by type -- powers the asset health donut/bar."""
    df = get_store().df("assets")
    by_status = df.groupby("status").size().reset_index(name="count")
    by_type = df.groupby(["asset_type", "status"]).size().reset_index(name="count")
    return {
        "by_status": by_status.to_dict(orient="records"),
        "by_type": by_type.to_dict(orient="records"),
    }


@router.get("/{asset_id}")
def get_asset(asset_id: str):
    df = get_store().df("assets")
    row = df[df["asset_id"] == asset_id]
    if row.empty:
        raise HTTPException(status_code=404, detail=f"Asset '{asset_id}' not found")
    return to_records(row)[0]
