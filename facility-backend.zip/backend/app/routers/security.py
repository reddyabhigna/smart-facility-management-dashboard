from fastapi import APIRouter, Query
from app.data_store import get_store
from app.utils import to_records, apply_filter

router = APIRouter(prefix="/api/security-events", tags=["security"])


@router.get("")
def list_security_events(
    facility_id: str | None = Query(None),
    severity: str | None = Query(None),
    status: str | None = Query(None),
):
    df = get_store().df("security_events")
    df = apply_filter(df, "facility_id", facility_id)
    df = apply_filter(df, "severity", severity)
    df = apply_filter(df, "status", status)
    return to_records(df.sort_values("event_time", ascending=False))


@router.get("/summary")
def security_summary():
    """Counts by severity/type/status -- powers the security overview panel."""
    df = get_store().df("security_events")
    return {
        "by_severity": df.groupby("severity").size().reset_index(name="count").to_dict(orient="records"),
        "by_type": df.groupby("event_type").size().reset_index(name="count").to_dict(orient="records"),
        "by_status": df.groupby("status").size().reset_index(name="count").to_dict(orient="records"),
        "open_count": int((df["status"] == "Open").sum()),
    }
